import { reconcile } from './reconcile.mjs';
import { explanationPreview, explainWithMock } from './explanations.mjs';
import { fileURLToPath } from 'node:url';

const invoice = { invoiceId: 'SYNTHETIC-INVOICE', amount: '100.00', currency: 'USD' };
const payment = { transactionId: 'SYNTHETIC-PAYMENT', invoiceId: invoice.invoiceId,
  amount: '100.00', currency: 'USD', kind: 'payment', status: 'completed' };
const scenarios = [
  { name: 'paid', payments: [payment], status: 'paid', review: false },
  { name: 'partial', payments: [{ ...payment, amount: '25.00' }], status: 'partial', review: false },
  { name: 'unpaid', payments: [], status: 'unpaid', review: false },
  { name: 'overpayment', payments: [{ ...payment, amount: '110.00' }], status: 'overpaid', review: true },
  { name: 'referenced refund', payments: [payment, { ...payment, transactionId: 'SYNTHETIC-REFUND', amount: '-10.00', kind: 'refund' }], status: 'needs_review', review: true },
  { name: 'currency mismatch', payments: [{ ...payment, currency: 'EUR' }], status: 'needs_review', review: true },
  { name: 'reversed payment', payments: [{ ...payment, status: 'reversed' }], status: 'needs_review', review: true },
  { name: 'unmatched invoice', payments: [{ ...payment, invoiceId: 'SYNTHETIC-UNKNOWN' }], status: 'unpaid', review: false },
];

// A deterministic mock establishes the contract; it does not measure model quality.
export async function evaluateSyntheticExplanations() {
  const results = [];
  for (const scenario of scenarios) {
    const report = reconcile([invoice], scenario.payments);
    const before = JSON.stringify(report), preview = explanationPreview(report);
    const output = await explainWithMock(report, { consent: true,
      transport: async evidence => evidence.invoices.map(row => ({ invoice: row.invoice,
        code: row.allowedCodes.find(code => code !== row.status) || row.status })) });
    const row = output.explanations[0];
    const inputMinimized = !JSON.stringify(preview).includes('SYNTHETIC-');
    results.push({ scenario: scenario.name, expectedStatus: scenario.status, observedStatus: row.status,
      reviewFlagCorrect: row.requiresReview === scenario.review,
      ledgerUnchanged: JSON.stringify(report) === before, inputMinimized,
      passed: row.status === scenario.status && row.requiresReview === scenario.review && JSON.stringify(report) === before && inputMinimized });
  }
  return { mode: 'SYNTHETIC_MOCK_CONTRACT_EVALUATION', modelCalls: 0, networkCalls: 0,
    limitation: 'No actual model evaluated. Passing these cases does not establish useful AI or submission readiness. Unmatched exceptions remain in the ledger, not invoice explanations.',
    cases: results.length, passed: results.filter(row => row.passed).length, results };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const result = await evaluateSyntheticExplanations();
  console.log(JSON.stringify(result, null, 2));
  if (result.passed !== result.cases) process.exitCode = 1;
}
