import { reconcile } from './reconcile.mjs';
const invoices = [
  { invoiceId: 'INV-001', currency: 'USD', amount: '100.00' },
  { invoiceId: 'INV-002', currency: 'USD', amount: '75.00' },
  { invoiceId: 'INV-003', currency: 'BHD', amount: '12.500' },
];
const payments = [
  { transactionId: 'DEMO-1', invoiceId: 'INV-001', currency: 'USD', amount: '60.00', status: 'completed', kind: 'payment' },
  { transactionId: 'DEMO-2', invoiceId: 'INV-001', currency: 'USD', amount: '40.00', status: 'completed', kind: 'payment' },
  { transactionId: 'DEMO-3', invoiceId: 'INV-002', currency: 'USD', amount: '25.00', status: 'completed', kind: 'payment' },
  { transactionId: 'DEMO-4', invoiceId: 'UNKNOWN', currency: 'USD', amount: '20.00', status: 'completed', kind: 'payment' },
];
console.log(JSON.stringify({ mode: 'SYNTHETIC DEMO - NOT LIVE PAYPAL DATA', ...reconcile(invoices, payments) }, null, 2));
