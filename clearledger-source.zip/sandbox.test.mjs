import test from 'node:test';
import assert from 'node:assert/strict';
import { readSandboxTransactions, normalizeSandboxRecords } from './paypal-sandbox.mjs';
import { reconcile } from './reconcile.mjs';
const start = '2026-10-01T00:00:00Z', end = '2026-10-02T00:00:00Z';
const config = { clientId: 'TEST_ONLY_ID', clientSecret: 'TEST_ONLY_SECRET', start, end };
const row = { transaction_info: { transaction_id: 'T1', invoice_id: 'I', transaction_status: 'S', transaction_event_code: 'T0006', transaction_amount: { value: '100.00', currency_code: 'USD' } } };
const page = (overrides = {}) => ({ page: 1, total_pages: 1, total_items: 1, transaction_details: [row], start_date: start, end_date: end, ...overrides });
const response = body => new Response(JSON.stringify(body), { status: 200 });
function fake(pages, calls = []) {
  return async (url, init) => {
    calls.push({ url, init });
    return url.includes('/oauth2/token') ? response({ access_token: 'TEST_ONLY_TOKEN', token_type: 'Bearer' }) : response(pages.shift());
  };
}
test('connector only uses fixed sandbox origin and read endpoint', async () => {
  const calls = []; const result = await readSandboxTransactions({ ...config, fetcher: fake([page()], calls) });
  assert.equal(result.records.length, 1);
  for (const call of calls) { assert.equal(new URL(call.url).origin, 'https://api-m.sandbox.paypal.com'); assert.equal(call.init.redirect, 'error'); }
  assert.equal(calls[1].init.method, 'GET'); assert.equal(new URL(calls[1].url).searchParams.get('fields'), 'transaction_info');
});
test('all pages collected before result returned', async () => {
  const second = { transaction_info: { ...row.transaction_info, transaction_id: 'T2' } };
  const result = await readSandboxTransactions({ ...config, fetcher: fake([
    page({ total_pages: 2, total_items: 2 }), page({ page: 2, total_pages: 2, total_items: 2, transaction_details: [second] }),
  ]) });
  assert.equal(result.coverage.pages, 2); assert.equal(result.records.length, 2);
});
test('invalid dates and missing credentials make no network call', async () => {
  const fetcher = () => { throw new Error('should not call'); };
  for (const values of [{ start: 'bad' }, { end: '2026-12-01T00:00:00Z' }, { end: start }, { clientSecret: '' }])
    await assert.rejects(readSandboxTransactions({ ...config, ...values, fetcher }), /PayPal sandbox/);
});
test('permission errors sanitized, no API-body or credential echo', async () => {
  let calls = 0;
  await assert.rejects(readSandboxTransactions({ ...config, fetcher: async () => ++calls === 1
    ? response({ access_token: 'TEST_ONLY_TOKEN', token_type: 'Bearer' })
    : new Response('TEST_ONLY_SECRET private account data', { status: 403 }) }), error => error.message === 'PayPal sandbox: HTTP_403');
});
test('page caps fail rather than returning partial data', async () => {
  await assert.rejects(readSandboxTransactions({ ...config, maxPages: 1, fetcher: fake([page({ total_pages: 2 })]) }), /page_limit_incomplete/);
});
test('changing page totals fail', async () => {
  await assert.rejects(readSandboxTransactions({ ...config, fetcher: fake([page({ total_pages: 2, total_items: 2 }), page({ page: 2, total_pages: 2, total_items: 3 })]) }), /snapshot_changed/);
});
test('empty, short and repeated pages fail', async () => {
  for (const bad of [page({ transaction_details: [] }), page({ total_items: 2 }), page({ page: 0 })])
    await assert.rejects(readSandboxTransactions({ ...config, fetcher: fake([bad]) }), /incomplete|pagination/);
});
test('shortened reporting coverage fails', async () => {
  for (const patch of [{ end_date: start }, { end_date: undefined }, { start_date: undefined }, { start_date: end }])
    await assert.rejects(readSandboxTransactions({ ...config, fetcher: fake([page(patch)]) }), /date_coverage_incomplete/);
});
test('normalization ignores fees, buyer payments and deposits as revenue', () => {
  assert.equal(normalizeSandboxRecords([row]).payments[0].kind, 'payment');
  for (const patch of [{ transaction_event_code: 'T0107' }, { transaction_event_code: 'T0300' }, { transaction_amount: { value: '-100.00', currency_code: 'USD' } }])
    assert.equal(normalizeSandboxRecords([{ transaction_info: { ...row.transaction_info, ...patch } }]).payments[0].kind, 'requires_review');
});
test('referenced refund with no invoice marks original invoice for review', () => {
  const refund = { transaction_info: { ...row.transaction_info, transaction_id: 'R', invoice_id: undefined,
    paypal_reference_id_type: 'TXN', paypal_reference_id: 'T1', transaction_event_code: 'T1107', transaction_amount: { value: '-10.00', currency_code: 'USD' } } };
  const normalized = normalizeSandboxRecords([refund, row]);
  assert.equal(normalized.payments[0].invoiceId, 'I');
  assert.equal(reconcile([{ invoiceId: 'I', amount: '100.00', currency: 'USD' }], normalized.payments).invoices[0].status, 'needs_review');
});
test('duplicate or conflicting source identity rejected', () => {
  assert.throws(() => normalizeSandboxRecords([row, row]), /duplicate_transaction/);
  const conflicting = { transaction_info: { ...row.transaction_info, transaction_id: 'R', invoice_id: 'OTHER', paypal_reference_id_type: 'TXN', paypal_reference_id: 'T1' } };
  assert.throws(() => normalizeSandboxRecords([row, conflicting]), /conflicting_invoice/);
});
test('missing refs are visible, not inferred by customer name or description', () => {
  const orphan = { transaction_info: { ...row.transaction_info, invoice_id: undefined, paypal_reference_id_type: 'TXN', paypal_reference_id: 'MISSING', transaction_note: 'paid invoice I' } };
  const result = normalizeSandboxRecords([orphan]);
  assert.equal(result.payments[0].invoiceId, null); assert.equal(result.warnings.length, 2);
});
test('reference chains resolve independent of record order', () => {
  const related = (id, parent) => ({ transaction_info: { ...row.transaction_info, transaction_id: id, invoice_id: undefined,
    paypal_reference_id_type: 'TXN', paypal_reference_id: parent, transaction_event_code: 'T1107' } });
  const result = normalizeSandboxRecords([related('R2', 'R1'), related('R1', 'T1'), row]);
  assert.ok(result.payments.every(p => p.invoiceId === 'I'));
  assert.throws(() => normalizeSandboxRecords([related('A', 'B'), related('B', 'A')]), /cyclic/);
});
test('invalid calendar dates are rejected', async () => {
  await assert.rejects(readSandboxTransactions({ ...config, start: '2026-02-30T00:00:00Z', end: '2026-03-05T00:00:00Z' }), /calendar/);
});
test('network exceptions never leak credentials', async () => {
  await assert.rejects(readSandboxTransactions({ ...config, fetcher: () => { throw new Error(config.clientSecret); } }), error => !error.message.includes(config.clientSecret));
});
test('malformed OAuth and JSON cannot proceed to reporting', async () => {
  for (const auth of [{ token_type: 'Bearer' }, { access_token: 'TEST', token_type: 'Basic' }, { access_token: 'BAD\r\nHEADER', token_type: 'Bearer' }])
    await assert.rejects(readSandboxTransactions({ ...config, fetcher: async () => response(auth) }), /invalid_/);
  await assert.rejects(readSandboxTransactions({ ...config, fetcher: async () => new Response('not JSON') }), /invalid_JSON/);
});
test('refresh timestamp changes abort the snapshot', async () => {
  await assert.rejects(readSandboxTransactions({ ...config, fetcher: fake([
    page({ total_pages: 2, total_items: 2, last_refreshed_datetime: start }),
    page({ page: 2, total_pages: 2, total_items: 2, last_refreshed_datetime: end }),
  ]) }), /snapshot_changed/);
});
test('empty valid report remains empty, not a missing page error', async () => {
  const report = await readSandboxTransactions({ ...config, fetcher: fake([page({ total_pages: 0, total_items: 0, transaction_details: [] })]) });
  assert.equal(report.records.length, 0);
});
test('reversed completed-looking payment never settles an invoice', () => {
  const normalized = normalizeSandboxRecords([{ transaction_info: { ...row.transaction_info, transaction_status: 'V' } }]);
  const report = reconcile([{ invoiceId: 'I', amount: '100.00', currency: 'USD' }], normalized.payments);
  assert.equal(report.invoices[0].paidMinor, '0'); assert.equal(report.invoices[0].status, 'needs_review');
});

test('response limit stops streaming and cancels before reading the remaining body', async () => {
  let pulls = 0, cancelled = false, calls = 0;
  const stream = new ReadableStream({
    pull(controller) { pulls++; controller.enqueue(new Uint8Array(1_000_000)); },
    cancel() { cancelled = true; },
  }, { highWaterMark: 0 });
  await assert.rejects(readSandboxTransactions({ ...config, fetcher: async () => {
    calls++; return new Response(stream);
  } }), error => error.message === 'PayPal sandbox: response_too_large');
  assert.equal(pulls, 5); assert.equal(cancelled, true); assert.equal(calls, 1);
});

test('response limit counts UTF-8 bytes rather than decoded characters', async () => {
  const body = JSON.stringify({ access_token: 'TEST', token_type: 'Bearer', padding: '\u00e9'.repeat(2_000_000) });
  assert.ok(body.length < 4_000_000);
  await assert.rejects(readSandboxTransactions({ ...config, fetcher: async () => new Response(body) }), /response_too_large/);
});

test('response boundary, malformed UTF-8 and stream errors are handled without leaking data', async () => {
  const auth = JSON.stringify({ access_token: 'TEST', token_type: 'Bearer' });
  let calls = 0;
  const report = await readSandboxTransactions({ ...config, fetcher: async () => ++calls === 1
    ? new Response(auth.padEnd(4_000_000, ' ')) : response(page()) });
  assert.equal(report.records.length, 1);
  for (const body of [new Uint8Array([0xc3, 0x28]), new ReadableStream({
    start(controller) { controller.error(new Error('PRIVATE_SOURCE_DATA')); },
  })]) {
    await assert.rejects(readSandboxTransactions({ ...config, fetcher: async () => new Response(body) }),
      error => error.message === 'PayPal sandbox: response_read_error');
  }
});
