import { readLocalJson } from './local-json.mjs';
import { reconcile } from './reconcile.mjs';
import { normalizeSandboxRecords, readSandboxTransactions, SandboxError } from './paypal-sandbox.mjs';
import { reviewWithLocalAI } from './local-ai.mjs';

try {
  const [invoicePath, mode, start, end] = process.argv.slice(2);
  if (!invoicePath || !mode || (mode === '--sandbox' && (!start || !end))) {
    console.error('Usage: node cli.mjs invoices.json transactions.json\nSandbox: node cli.mjs invoices.json --sandbox START_UTC END_UTC');
    process.exitCode = 2;
  } else {
    const invoices = await readLocalJson(invoicePath);
    const snapshot = mode === '--sandbox'
      ? await readSandboxTransactions({ clientId: process.env.PAYPAL_SANDBOX_CLIENT_ID, clientSecret: process.env.PAYPAL_SANDBOX_CLIENT_SECRET, start, end })
      : { mode: 'LOCAL_IMPORT_UNVERIFIED_SOURCE', records: await readLocalJson(mode), coverage: null, warnings: ['Imported data source and completeness are not verified.'] };
    const normalized = normalizeSandboxRecords(snapshot.records);
    const report = reconcile(invoices, normalized.payments);
    let aiReview = null;
    if (process.env.ENABLE_LOCAL_AI_REVIEW === 'true') {
      aiReview = await reviewWithLocalAI(report, { model: process.env.LOCAL_AI_MODEL, consent: true });
    }
    console.log(JSON.stringify({ mode: snapshot.mode, coverage: snapshot.coverage, warnings: [...snapshot.warnings, ...normalized.warnings], ...report, aiReview }, null, 2));
  }
} catch (error) {
  console.error(error instanceof SandboxError ? error.message : 'Reconciliation stopped: invalid/unreadable input or unsupported accounting data.');
  process.exitCode = 1;
}
