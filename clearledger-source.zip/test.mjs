import test from 'node:test';
import assert from 'node:assert/strict';
import { minorUnits, reconcile, explanationEvidence } from './reconcile.mjs';
const invoice = { invoiceId: 'I', amount: '100.00', currency: 'USD' };
const payment = { transactionId: 'T', invoiceId: 'I', amount: '100.00', currency: 'USD', kind: 'payment', status: 'completed' };
test('exact decimal arithmetic and three-decimal BHD', () => {
  assert.equal(minorUnits('0.10', 'USD') + minorUnits('0.20', 'USD'), 30n);
  assert.equal(minorUnits('12.501', 'BHD'), 12501n);
});
test('invalid, nonfinite and overprecise amounts rejected', () => {
  for (const v of ['NaN', 'Infinity', '1e4', '1.001', '', ' 1']) assert.throws(() => minorUnits(v, 'USD'));
  assert.throws(() => minorUnits(1, 'USD')); assert.throws(() => minorUnits('1', 'XYZ'));
});
test('paid and split payments reconcile exactly', () => {
  assert.equal(reconcile([invoice], [payment]).invoices[0].status, 'paid');
  const result = reconcile([invoice], [{ ...payment, amount: '40.00' }, { ...payment, transactionId: 'T2', amount: '60.00' }]);
  assert.equal(result.invoices[0].balanceMinor, '0');
});
test('partial, unpaid, overpaid are distinct', () => {
  assert.equal(reconcile([invoice], []).invoices[0].status, 'unpaid');
  assert.equal(reconcile([invoice], [{ ...payment, amount: '20.00' }]).invoices[0].status, 'partial');
  assert.equal(reconcile([invoice], [{ ...payment, amount: '101.00' }]).invoices[0].status, 'overpaid');
});
test('duplicates stop accounting rather than double-count', () => {
  assert.throws(() => reconcile([invoice], [payment, payment]));
  assert.throws(() => reconcile([invoice, invoice], []));
});
test('currency mismatch never settles invoice', () => {
  const result = reconcile([invoice], [{ ...payment, currency: 'EUR' }]);
  assert.equal(result.invoices[0].status, 'needs_review'); assert.equal(result.exceptions[0].reason, 'currency_mismatch');
});
test('pending, refunds and unmatched isolated for review', () => {
  const result = reconcile([invoice], [
    { ...payment, status: 'pending' }, { ...payment, transactionId: 'R', amount: '-10.00', kind: 'refund' },
    { ...payment, transactionId: 'U', invoiceId: 'X' },
  ]);
  assert.equal(result.exceptions.length, 3); assert.equal(result.invoices[0].paidMinor, '0');
  assert.equal(result.invoices[0].status, 'needs_review');
});
test('refund prevents a misleading paid classification', () => {
  const result = reconcile([invoice], [payment, { ...payment, transactionId: 'REFUND', kind: 'refund', amount: '-10.00' }]);
  assert.equal(result.invoices[0].status, 'needs_review');
});
test('explanation evidence leaves accounting intact and JSON-safe', () => {
  const report = reconcile([invoice], [payment]); const original = JSON.stringify(report);
  const bundle = explanationEvidence(report); assert.equal(JSON.stringify(bundle.evidence), original);
  bundle.evidence.invoices[0].paidMinor = '999999';
  bundle.evidence.invoices[0].transactionIds.push('INVENTED');
  assert.equal(JSON.stringify(report), original);
});

test('160 synthetic ledgers preserve exact totals, review gates, ordering and source inputs', () => {
  const decimal = (units, digits) => {
    const sign = units < 0n ? '-' : '';
    const value = (units < 0n ? -units : units).toString().padStart(digits + 1, '0');
    return `${sign}${value.slice(0, -digits)}.${value.slice(-digits)}`;
  };
  for (const [currency, digits] of [['USD', 2], ['EUR', 2], ['GBP', 2], ['BHD', 3]]) {
    for (let index = 0; index < 40; index++) {
      const due = (index % 2 ? 9007199254740993n : 101n) + BigInt(index);
      const paid = [0n, due - 1n, due, due + 1n][index % 4];
      const sourceInvoice = { invoiceId: 'CASE', currency, amount: decimal(due, digits) };
      const rows = [paid / 3n, paid - paid / 3n].filter(value => value > 0n).map((value, part) => ({
        transactionId: `P${part}`, invoiceId: 'CASE', currency,
        amount: decimal(value, digits), kind: 'payment', status: 'completed',
      }));
      if (index % 5 === 0) rows.push({ ...payment, transactionId: 'PENDING', invoiceId: 'CASE', currency,
        amount: decimal(due, digits), status: 'pending' });
      if (index % 7 === 0) rows.push({ ...payment, transactionId: 'REFUND', invoiceId: 'CASE', currency,
        amount: decimal(-1n, digits), kind: 'refund' });
      rows.push({ ...payment, transactionId: 'ORPHAN', invoiceId: 'MISSING', currency,
        amount: decimal(1n, digits) });
      const original = JSON.stringify({ sourceInvoice, rows });
      const result = reconcile([sourceInvoice], rows);
      const ledger = result.invoices[0];
      assert.equal(ledger.dueMinor, due.toString());
      assert.equal(ledger.paidMinor, paid.toString());
      assert.equal(ledger.balanceMinor, (due - paid).toString());
      const review = index % 5 === 0 || index % 7 === 0;
      assert.equal(ledger.status, review ? 'needs_review' : ['unpaid', 'partial', 'paid', 'overpaid'][index % 4]);
      assert.deepEqual([...ledger.transactionIds].sort(), rows.filter(row => row.transactionId.startsWith('P') && row.status === 'completed').map(row => row.transactionId).sort());
      const canonical = report => ({ ...report, invoices: report.invoices.map(row => ({ ...row,
        transactionIds: [...row.transactionIds].sort() })), exceptions: [...report.exceptions].sort((a, b) => a.transactionId.localeCompare(b.transactionId)) });
      assert.deepEqual(canonical(result), canonical(reconcile([sourceInvoice], [...rows].reverse())));
      assert.equal(JSON.stringify({ sourceInvoice, rows }), original);
    }
  }
});
