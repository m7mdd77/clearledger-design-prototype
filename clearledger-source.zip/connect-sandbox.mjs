import http from 'node:http';
import { randomBytes } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { readSandboxTransactions, SandboxError } from './paypal-sandbox.mjs';

export function createConnectionServer({ read = readSandboxTransactions } = {}) {
  const token = randomBytes(32).toString('hex');
  let busy = false;
  let lastResult = { status: 'not_connected' };
  const server = http.createServer(async (req, res) => {
    const origin = `http://127.0.0.1:${req.socket.localPort}`;
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    // Native form POSTs get Origin: null under no-referrer, blocking our own form.
    res.setHeader('Referrer-Policy', 'same-origin');
    res.setHeader('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
    const send = (status, value, type = 'text/plain') => { res.writeHead(status, { 'Content-Type': `${type}; charset=utf-8` }); res.end(value); };
    if (req.headers.host !== origin.slice(7)) return send(403, 'Host not allowed');
    if (req.url === '/status' && req.method === 'GET') return send(200, JSON.stringify(lastResult), 'application/json');
    if (req.url !== '/') return send(404, 'Not found');
    if (req.method === 'GET') {
      return send(200, `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Clearledger sandbox connection</title>
        <style>body{font:16px system-ui;background:#f5f8f7;color:#172820;max-width:620px;margin:48px auto;padding:20px}label{display:block;margin:20px 0}input{display:block;box-sizing:border-box;width:100%;padding:12px;margin-top:6px}button{padding:12px 18px;background:#087956;color:white;border:0}p{line-height:1.6}</style>
        <h1>PayPal sandbox connection</h1><p>Read-only Transaction Search. Credentials stay in this local request; they are not logged or saved. No live payments or spending.</p>
        <form method="post" autocomplete="off"><input type="hidden" name="token" value="${token}">
        <label>Sandbox client ID<input name="clientId" type="password" autocomplete="off" maxlength="4096" required></label>
        <label>Sandbox secret<input name="clientSecret" type="password" autocomplete="off" maxlength="4096" required></label>
        <label>Start UTC<input name="start" value="2026-10-01T00:00:00Z" required></label>
        <label>End UTC<input name="end" value="2026-10-05T00:00:00Z" required></label>
        <button type="submit">Test sandbox reporting</button></form></html>`, 'text/html');
    }
    if (req.method !== 'POST') return send(405, 'Method not allowed');
    if (req.headers.origin !== origin || !/^application\/x-www-form-urlencoded(?:;\s*charset=UTF-8)?$/i.test(req.headers['content-type'] || '')) return send(403, 'Same-origin form required');
    if (busy) return send(409, 'A sandbox check is already running');
    busy = true;
    let fields;
    try {
      const buffer = Buffer.alloc(16384); let length = 0;
      for await (const chunk of req) {
        if (chunk.length > buffer.length - length) { send(413, 'Request too large'); return; }
        chunk.copy(buffer, length); length += chunk.length;
      }
      fields = new URLSearchParams(new TextDecoder('utf-8', { fatal: true }).decode(buffer.subarray(0, length)));
      buffer.fill(0);
      if (fields.get('token') !== token || [...fields.keys()].length !== 5
        || ['token', 'clientId', 'clientSecret', 'start', 'end'].some(key => fields.getAll(key).length !== 1)) return send(403, 'Invalid connection request');
      const snapshot = await read({ clientId: fields.get('clientId'), clientSecret: fields.get('clientSecret'), start: fields.get('start'), end: fields.get('end') });
      // Only aggregate proof is retained. No credentials or transaction details persist.
      lastResult = { status: 'verified', source: snapshot.mode, recordCount: snapshot.records.length,
        verifiedAt: new Date().toISOString(), warnings: snapshot.warnings, scope: 'sandbox_reporting_only' };
      send(200, JSON.stringify(lastResult, null, 2), 'application/json');
    } catch (error) {
      lastResult = { status: 'failed', detail: error instanceof SandboxError ? error.message : 'Sandbox check failed; no details retained' };
      send(502, JSON.stringify(lastResult), 'application/json');
    } finally {
      if (fields) { fields.delete('clientId'); fields.delete('clientSecret'); }
      busy = false;
    }
  });
  server.requestTimeout = 20000;
  server.headersTimeout = 10000;
  return server;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const server = createConnectionServer();
  server.on('error', () => { console.error('Sandbox connection server unavailable'); process.exitCode = 1; });
  server.listen(3230, '127.0.0.1', () => console.log('Sandbox connection: http://127.0.0.1:3230/'));
}
