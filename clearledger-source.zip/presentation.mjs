const digits = { USD: 2, EUR: 2, GBP: 2, BHD: 3 };

export function formatMinor(value, currency) {
  if (!Object.hasOwn(digits, currency) || typeof value !== 'string' || !/^-?\d+$/.test(value)) throw new Error('Invalid display amount');
  const amount = BigInt(value), magnitude = amount < 0n ? -amount : amount, scale = 10n ** BigInt(digits[currency]);
  return `${amount < 0n ? '-' : ''}${(magnitude / scale).toLocaleString('en-US')}.${(magnitude % scale).toString().padStart(digits[currency], '0')} ${currency}`;
}

export function presentReport(report, masked = true) {
  const invoices = new Map(), transactions = new Map();
  const invoice = id => {
    if (!invoices.has(id)) invoices.set(id, `Invoice ${String(invoices.size + 1).padStart(3, '0')}`);
    return masked ? invoices.get(id) : id;
  };
  const transaction = id => {
    if (!transactions.has(id)) transactions.set(id, `Transaction ${String(transactions.size + 1).padStart(3, '0')}`);
    return masked ? transactions.get(id) : id;
  };
  return {
    mode: report.mode, identifiers: masked ? 'masked local aliases' : 'full identifiers',
    invoices: report.invoices.map(row => ({ invoiceId: invoice(row.invoiceId), currency: row.currency,
      dueMinor: row.dueMinor, paidMinor: row.paidMinor, balanceMinor: row.balanceMinor,
      status: row.status, transactionIds: row.transactionIds.map(transaction) })),
    exceptions: report.exceptions.map(row => ({ transactionId: transaction(row.transactionId), invoiceId: row.invoiceId ? invoice(row.invoiceId) : null, reason: row.reason })),
    warnings: (report.warnings || []).map(row => typeof row === 'string' ? row : { transactionId: transaction(row.transactionId), reason: row.reason }),
    notice: report.notice,
  };
}

export const statusNames = { paid: 'Paid', partial: 'Partially paid', unpaid: 'Unpaid', overpaid: 'Overpaid', needs_review: 'Needs review' };
export const reasonNames = {
  not_completed: 'Pending, reversed or unverified transaction', non_payment_or_refund: 'Refund or non-payment event',
  unmatched_invoice: 'No matching invoice', currency_mismatch: 'Payment currency differs from invoice',
  reference_outside_window_or_unavailable: 'Related transaction is outside this report', missing_invoice_reference: 'No invoice reference supplied',
};
