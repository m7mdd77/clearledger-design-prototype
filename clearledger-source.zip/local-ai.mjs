import { explanationPreview } from './explanations.mjs';

const actions = Object.freeze({
  paid: ['check_reporting_window'],
  partial: ['check_reporting_window', 'check_missing_payment'],
  unpaid: ['check_reporting_window', 'check_missing_payment'],
  overpaid: ['review_overpayment'],
  needs_review: ['review_exception', 'check_reporting_window'],
});

// The model proposes a review queue; it cannot change accounting or trigger actions.
export async function reviewWithLocalAI(report, { model, consent = false, fetchImpl = fetch } = {}) {
  if (consent !== true) throw new Error('Explicit AI opt-in required');
  if (typeof model !== 'string' || !/^[a-zA-Z0-9_.:/-]{1,128}$/.test(model)) throw new Error('Choose an installed local model');
  const evidence = explanationPreview(report).invoices;
  if (evidence.length > 100) throw new Error('AI review supports at most 100 invoices');
  const preview = evidence.map(row => ({ invoice: row.invoice, status: row.status,
    reasons: row.allowedCodes, allowedActions: actions[row.status] }));
  let body;
  try {
    const response = await fetchImpl('http://127.0.0.1:11434/api/chat', {
      method: 'POST', redirect: 'error', signal: AbortSignal.timeout(60000),
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, stream: false, options: { temperature: 0 },
        format: { type: 'object', additionalProperties: false, required: ['reviews'], properties: {
          reviews: { type: 'array', items: { type: 'object', additionalProperties: false,
            required: ['invoice', 'priority', 'action'], properties: {
              invoice: { type: 'string' }, priority: { type: 'integer', minimum: 1, maximum: 3 }, action: { type: 'string' },
            } } },
        } },
        messages: [{ role: 'system', content: 'Prioritize human reconciliation review: 1 urgent, 3 routine. Return each invoice once, selecting only its allowedActions. Never infer payments, contact customers, or modify accounting.' },
          { role: 'user', content: JSON.stringify(preview) }],
      }),
    });
    if (!response.ok || !response.body) throw new Error('Unavailable');
    const reader = response.body.getReader();
    const buffer = new Uint8Array(262144);
    let length = 0;
    try {
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value.byteLength > buffer.length - length) throw new Error('Oversize');
        buffer.set(value, length); length += value.byteLength;
      }
      body = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(buffer.subarray(0, length)));
    } finally { await reader.cancel().catch(() => {}); reader.releaseLock(); }
    if (body.done !== true || typeof body.message?.content !== 'string') throw new Error('Incomplete');
    body = JSON.parse(body.message.content);
  } catch { throw new Error('Local AI unavailable; accounting unchanged'); }
  if (!body || Object.keys(body).length !== 1 || !Array.isArray(body.reviews) || body.reviews.length !== preview.length) throw new Error('Invalid AI review');
  const byAlias = new Map(preview.map(row => [row.invoice, row]));
  const seen = new Set();
  for (const row of body.reviews) {
    if (!row || Object.keys(row).length !== 3 || !byAlias.has(row.invoice) || seen.has(row.invoice)
      || !Number.isInteger(row.priority) || row.priority < 1 || row.priority > 3
      || !byAlias.get(row.invoice).allowedActions.includes(row.action)) throw new Error('Invalid AI review');
    seen.add(row.invoice);
  }
  return { mode: 'LOCAL_MODEL_REVIEW', model, humanApprovalRequired: true,
    reviews: body.reviews.toSorted((a, b) => a.priority - b.priority) };
}
