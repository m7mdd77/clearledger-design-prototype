import { reconcile } from './reconcile.mjs';
import { reviewWithLocalAI } from './local-ai.mjs';

try {
  const report = reconcile([{ invoiceId: 'SYNTHETIC-INVOICE', amount: '100.00', currency: 'USD' }], []);
  const result = await reviewWithLocalAI(report, { model: process.env.LOCAL_AI_MODEL, consent: true });
  console.log(JSON.stringify({ dataSource: 'SYNTHETIC', ...result }, null, 2));
} catch (error) { console.error(error.message); process.exitCode = 1; }
