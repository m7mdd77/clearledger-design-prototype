import { reconcile } from './reconcile.mjs';
import { normalizeSandboxRecords } from './paypal-sandbox.mjs';
import { presentReport } from './presentation.mjs';

export function createReportSession() {
  let revision = 0, current = null;
  return {
    get current() { return current; },
    async load(loader, mode) {
      if (typeof loader !== 'function' || !['SYNTHETIC_DEMO', 'LOCAL_IMPORT_UNVERIFIED_SOURCE'].includes(mode)) throw new Error('Invalid report load');
      const request = ++revision;
      try {
        const { invoices, records } = await loader();
        if (request !== revision) return false;
        const normalized = normalizeSandboxRecords(records);
        const candidate = { ...reconcile(invoices, normalized.payments), mode,
          warnings: ['Source and completeness are not verified. This report does not prove lifetime settlement.',
            'Refunds and other uncertain events require review; they are not silently subtracted.', ...normalized.warnings] };
        presentReport(candidate, true);
        current = candidate;
        return true;
      } catch {
        if (request !== revision) return false;
        throw new Error('Report load failed; previous report preserved');
      }
    },
  };
}
