async function smallJson(url, fetchImpl) {
  const response = await fetchImpl(url, { redirect: 'error', signal: AbortSignal.timeout(5000) });
  if (!response.ok || !response.body) throw new Error('Unavailable');
  const reader = response.body.getReader(); const buffer = new Uint8Array(65536); let size = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read(); if (done) break;
      if (value.length > buffer.length - size) throw new Error('Oversize');
      buffer.set(value, size); size += value.length;
    }
    return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(buffer.subarray(0, size)));
  } finally { await reader.cancel().catch(() => {}); reader.releaseLock(); }
}

export async function integrationStatus({ model = 'qwen2.5:0.5b', fetchImpl = fetch } = {}) {
  const result = { sandbox: { status: 'unavailable' }, ai: { status: 'unavailable' } };
  try {
    const proof = await smallJson('http://127.0.0.1:3230/status', fetchImpl);
    if (proof.status === 'verified' && proof.source === 'PAYPAL_SANDBOX_READ_ONLY'
      && Number.isSafeInteger(proof.recordCount) && proof.recordCount >= 0
      && typeof proof.verifiedAt === 'string' && Number.isFinite(Date.parse(proof.verifiedAt))) {
      result.sandbox = { status: 'verified', recordCount: proof.recordCount, verifiedAt: proof.verifiedAt };
    } else result.sandbox.status = 'not_verified';
  } catch { /* Do not echo local provider responses. */ }
  try {
    const runtime = await smallJson('http://127.0.0.1:11434/api/tags', fetchImpl);
    if (Array.isArray(runtime.models)) result.ai.status = runtime.models.some(row => row?.name === model) ? 'model_available' : 'model_missing';
  } catch { /* An installed adapter is not evidence of running inference. */ }
  return result;
}
