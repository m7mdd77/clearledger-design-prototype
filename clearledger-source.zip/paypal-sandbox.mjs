import { minorUnits } from './reconcile.mjs';

const ORIGIN = 'https://api-m.sandbox.paypal.com';
const paymentCodes = new Set(['T0000', 'T0002', 'T0003', 'T0004', 'T0005', 'T0006', 'T0007', 'T0011', 'T0012', 'T0018', 'T0023']);

export class SandboxError extends Error {
  constructor(code) { super(`PayPal sandbox: ${code}`); this.code = code; }
}

function text(value, field, optional = false) {
  if (optional && value == null) return null;
  if (typeof value !== 'string' || !value.trim() || value.length > 256) throw new SandboxError(`invalid_${field}`);
  return value;
}

function range(start, end) {
  const iso = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?Z$/;
  if (!iso.test(start) || !iso.test(end)) throw new SandboxError('UTC_date_required');
  const from = Date.parse(start), to = Date.parse(end);
  if (!Number.isFinite(from) || !Number.isFinite(to) || to <= from || to - from > 31 * 86400e3) throw new SandboxError('invalid_date_range');
  if (new Date(from).toISOString().slice(0,19) !== start.slice(0,19) || new Date(to).toISOString().slice(0,19) !== end.slice(0,19)) throw new SandboxError('invalid_calendar_date');
  return { start: new Date(from).toISOString(), end: new Date(to).toISOString() };
}

async function readJson(fetcher, url, init) {
  let response;
  try { response = await fetcher(url, { ...init, redirect: 'error', signal: AbortSignal.timeout(15000) }); }
  catch { throw new SandboxError('network_or_redirect_error'); }
  if (!response.ok) throw new SandboxError(`HTTP_${response.status}`);
  // Never echo response bodies or authorization headers into errors/logs.
  let reader, body;
  try {
    reader = response.body.getReader();
    const bytes = new Uint8Array(4_000_000);
    let length = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!(value instanceof Uint8Array)) throw new SandboxError('response_read_error');
      if (value.byteLength > bytes.length - length) throw new SandboxError('response_too_large');
      bytes.set(value, length); length += value.byteLength;
    }
    body = new TextDecoder('utf-8', { fatal: true }).decode(bytes.subarray(0, length));
  } catch (error) {
    try { await reader?.cancel(); } catch { /* Keep transport details out of errors. */ }
    if (error instanceof SandboxError) throw error;
    throw new SandboxError('response_read_error');
  } finally {
    reader?.releaseLock();
  }
  try { return JSON.parse(body); } catch { throw new SandboxError('invalid_JSON'); }
}

export async function readSandboxTransactions({ clientId, clientSecret, start, end, fetcher = fetch, maxPages = 20 }) {
  const dates = range(start, end);
  if (!Number.isInteger(maxPages) || maxPages < 1 || maxPages > 100) throw new SandboxError('invalid_page_limit');
  if (typeof clientId !== 'string' || typeof clientSecret !== 'string' || !clientId || !clientSecret) throw new SandboxError('sandbox_credentials_required');
  const auth = await readJson(fetcher, `${ORIGIN}/v1/oauth2/token`, {
    method: 'POST', headers: { Authorization: `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString('base64')}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=client_credentials',
  });
  const token = auth.access_token;
  if (typeof token !== 'string' || !token || token.length > 4096 || /\s/.test(token)) throw new SandboxError('invalid_access_token');
  if (typeof auth.token_type !== 'string' || auth.token_type.toLowerCase() !== 'bearer') throw new SandboxError('invalid_token_type');
  const records = []; let expectedPages, expectedItems, refreshedAt;
  for (let page = 1; page <= maxPages; page++) {
    const url = new URL('/v1/reporting/transactions', ORIGIN);
    for (const [key, value] of Object.entries({ start_date: dates.start, end_date: dates.end, fields: 'transaction_info', balance_affecting_records_only: 'Y', page_size: 100, page })) url.searchParams.set(key, value);
    const result = await readJson(fetcher, url.href, { method: 'GET', headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' } });
    if (!Array.isArray(result.transaction_details) || !Number.isInteger(result.total_pages) || result.total_pages < 0 || !Number.isInteger(result.total_items) || result.total_items < 0 || result.page !== page) throw new SandboxError('invalid_pagination');
    if (result.total_pages > maxPages) throw new SandboxError('page_limit_incomplete');
    if (page === 1) { expectedPages = result.total_pages; expectedItems = result.total_items; refreshedAt = result.last_refreshed_datetime || null; }
    if (expectedPages !== result.total_pages || expectedItems !== result.total_items || refreshedAt !== (result.last_refreshed_datetime || null)) throw new SandboxError('snapshot_changed_retry_required');
    if (result.transaction_details.length > 100 || (expectedItems > 0 && !result.transaction_details.length)) throw new SandboxError('incomplete_page');
    const returnedStart = Date.parse(result.start_date), returnedEnd = Date.parse(result.end_date);
    if (!Number.isFinite(returnedStart) || !Number.isFinite(returnedEnd) || returnedStart > Date.parse(dates.start) || returnedEnd < Date.parse(dates.end)) throw new SandboxError('date_coverage_incomplete');
    records.push(...result.transaction_details);
    if (page >= expectedPages) {
      if (records.length !== expectedItems) throw new SandboxError('record_count_incomplete');
      return { mode: 'PAYPAL_SANDBOX_READ_ONLY', records, coverage: { ...dates, pages: page, recordCount: records.length, refreshedAt },
        warnings: ['This is a bounded reporting window, not proof of lifetime settlement. PayPal reporting may lag executed transactions.'] };
    }
  }
  throw new SandboxError('page_limit_incomplete');
}

export function normalizeSandboxRecords(records) {
  if (!Array.isArray(records) || records.length > 10000) throw new SandboxError('invalid_record_collection');
  const seen = new Set();
  const rows = records.map(record => {
    const i = record?.transaction_info;
    if (!i || typeof i !== 'object') throw new SandboxError('missing_transaction_info');
    const transactionId = text(i.transaction_id, 'transaction_id');
    if (seen.has(transactionId)) throw new SandboxError('duplicate_transaction_requires_review');
    seen.add(transactionId);
    const currency = text(i.transaction_amount?.currency_code, 'currency');
    const amount = text(i.transaction_amount?.value, 'amount');
    const units = minorUnits(amount, currency);
    const eventCode = text(i.transaction_event_code, 'event_code');
    const statusCode = text(i.transaction_status, 'status');
    const invoiceId = text(i.invoice_id, 'invoice_id', true);
    const referenceId = i.paypal_reference_id_type === 'TXN' ? text(i.paypal_reference_id, 'reference_id', true) : null;
    return { transactionId, invoiceId, currency, amount, eventCode, statusCode, referenceId,
      status: statusCode === 'S' ? 'completed' : statusCode === 'P' ? 'pending' : statusCode === 'V' ? 'reversed' : 'unverified',
      kind: paymentCodes.has(eventCode) && units > 0n ? 'payment' : 'requires_review' };
  });
  const byId = new Map(rows.map(row => [row.transactionId, row]));
  const warnings = [];
  const resolved = new Set();
  function resolve(row, ancestors = new Set()) {
    if (resolved.has(row.transactionId)) return row.invoiceId;
    if (ancestors.has(row.transactionId) || ancestors.size > 100) throw new SandboxError('cyclic_or_excessive_reference_chain');
    if (row.referenceId) {
      const parent = byId.get(row.referenceId);
      if (parent) {
        const parentInvoice = resolve(parent, new Set([...ancestors, row.transactionId]));
        if (parentInvoice && row.invoiceId && parentInvoice !== row.invoiceId) throw new SandboxError('conflicting_invoice_reference');
        if (!row.invoiceId) row.invoiceId = parentInvoice;
      } else warnings.push({ transactionId: row.transactionId, reason: 'reference_outside_window_or_unavailable' });
    }
    resolved.add(row.transactionId); return row.invoiceId;
  }
  for (const row of rows) {
    resolve(row);
    if (!row.invoiceId) warnings.push({ transactionId: row.transactionId, reason: 'missing_invoice_reference' });
  }
  return { payments: rows, warnings };
}
