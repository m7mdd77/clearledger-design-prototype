// Mock-only adapter boundary. No SDK, credentials, network or financial actions.
const messages = Object.freeze({
  paid: 'Matched completed payments equal the invoice amount in this reporting window.',
  partial: 'Matched completed payments cover only part of this invoice.',
  unpaid: 'No completed payment matched this invoice in this reporting window.',
  overpaid: 'Matched completed payments exceed the invoice amount; review the difference.',
  needs_review: 'An exception prevents a reliable paid classification. Human review is required.',
  not_completed: 'A linked transaction is pending, reversed or unverified.',
  non_payment_or_refund: 'A linked refund or non-payment event requires review; it is not automatically netted.',
  currency_mismatch: 'A linked payment uses a different currency and was not included in the matched total.',
});

function freeze(value) {
  Object.freeze(value);
  for (const child of Object.values(value)) if (child && typeof child === 'object') freeze(child);
  return value;
}

export function explanationPreview(report) {
  if (!report || !Array.isArray(report.invoices) || !Array.isArray(report.exceptions)
    || report.invoices.length > 10000 || report.exceptions.length > 10000) throw new Error('Invalid explanation evidence');
  if (report.exceptions.some(row => !row || !['not_completed', 'non_payment_or_refund', 'currency_mismatch', 'unmatched_invoice'].includes(row.reason))) throw new Error('Invalid explanation evidence');
  const ids = new Set();
  const invoices = report.invoices.map((row, index) => {
    if (!row || typeof row.invoiceId !== 'string' || !row.invoiceId.trim() || ids.has(row.invoiceId)
      || !['paid', 'partial', 'unpaid', 'overpaid', 'needs_review'].includes(row.status)) throw new Error('Invalid explanation evidence');
    ids.add(row.invoiceId);
    const reasons = [...new Set(report.exceptions.filter(item => item.invoiceId === row.invoiceId).map(item => item.reason))];
    if (reasons.length && row.status !== 'needs_review') throw new Error('Inconsistent explanation evidence');
    if (reasons.some(reason => !['not_completed', 'non_payment_or_refund', 'currency_mismatch', 'unmatched_invoice'].includes(reason))) throw new Error('Invalid explanation evidence');
    return { invoice: `Invoice ${String(index + 1).padStart(3, '0')}`, status: row.status,
      allowedCodes: [row.status, ...reasons.filter(reason => Object.hasOwn(messages, reason))] };
  });
  return freeze({ mode: 'mock-only', task: 'Choose one supported explanation code per invoice. Do not infer financial facts.', invoices });
}

export async function explainWithMock(report, { consent = false, transport, timeoutMs = 1000 } = {}) {
  if (consent !== true) throw new Error('Explicit explanation opt-in required');
  if (typeof transport !== 'function' || !Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 10000) throw new Error('Invalid mock transport configuration');
  const preview = explanationPreview(report);
  let timer;
  let response;
  const controller = new AbortController();
  try {
    response = await Promise.race([
      Promise.resolve().then(() => transport(preview, { signal: controller.signal })),
      new Promise((_, reject) => { timer = setTimeout(() => { controller.abort(); reject(new Error('Timeout')); }, timeoutMs); }),
    ]);
    // Copy untrusted output before validation; never attach it to the ledger.
    response = structuredClone(response);
  } catch {
    throw new Error('Mock explanation unavailable; accounting unchanged');
  } finally {
    clearTimeout(timer);
  }
  if (!Array.isArray(response) || response.length !== preview.invoices.length) throw new Error('Invalid mock explanation response');
  const seen = new Set();
  const evidence = new Map(preview.invoices.map(row => [row.invoice, row]));
  const explanations = response.map(row => {
    if (!row || typeof row !== 'object' || Object.keys(row).length !== 2
      || !Object.hasOwn(row, 'invoice') || !Object.hasOwn(row, 'code')
      || !evidence.has(row.invoice) || seen.has(row.invoice)
      || !evidence.get(row.invoice).allowedCodes.includes(row.code)) throw new Error('Invalid mock explanation response');
    seen.add(row.invoice);
    const source = evidence.get(row.invoice);
    return { invoice: row.invoice, status: source.status, requiresReview: ['needs_review', 'overpaid'].includes(source.status),
      text: messages[row.code], evidenceCodes: [...source.allowedCodes] };
  });
  return freeze({ mode: 'MOCK_EXPLANATION_NOT_LIVE_AI', humanReviewRequired: true, explanations });
}
