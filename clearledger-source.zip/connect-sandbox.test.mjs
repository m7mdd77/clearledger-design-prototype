import test from 'node:test';
import assert from 'node:assert/strict';
import { createConnectionServer } from './connect-sandbox.mjs';

test('sandbox connection requires origin and token; returns aggregate evidence without secrets', async () => {
  let calls = 0;
  const server = createConnectionServer({ read: async input => {
    calls++; assert.equal(input.clientSecret, 'PRIVATE_SECRET');
    return { mode: 'PAYPAL_SANDBOX_READ_ONLY', records: [{ private: 'DATA' }], warnings: [] };
  } });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  try {
    const home = await fetch(origin);
    assert.equal(home.headers.get('referrer-policy'), 'same-origin');
    const html = await home.text();
    const token = html.match(/name="token" value="([a-f0-9]+)"/)[1];
    const body = new URLSearchParams({ token, clientId: 'ID', clientSecret: 'PRIVATE_SECRET', start: '2026-10-01T00:00:00Z', end: '2026-10-05T00:00:00Z' });
    assert.equal((await fetch(origin, { method: 'POST', body })).status, 403);
    assert.equal((await fetch(origin, { method: 'POST', body, headers: { Origin: 'null' } })).status, 403);
    assert.equal((await fetch(origin, { method: 'POST', body, headers: { Origin: 'https://evil.example' } })).status, 403);
    const response = await fetch(origin, { method: 'POST', body, headers: { Origin: origin } });
    assert.equal(response.status, 200);
    const result = await response.text();
    assert.ok(!result.includes('PRIVATE_SECRET')); assert.ok(!result.includes('DATA'));
    assert.equal(JSON.parse(result).recordCount, 1); assert.equal(calls, 1);
    assert.equal((await (await fetch(origin + '/status')).json()).status, 'verified');
    assert.equal((await fetch(origin + '/.env')).status, 404);
    body.set('token', 'wrong');
    assert.equal((await fetch(origin, { method: 'POST', body, headers: { Origin: origin } })).status, 403);
  } finally { await new Promise(resolve => { server.close(resolve); server.closeAllConnections(); }); }
});

test('malformed, duplicate and oversized credential forms never reach PayPal', async () => {
  let calls = 0;
  const server = createConnectionServer({ read: async () => { calls++; throw new Error('Unexpected network'); } });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  try {
    const token = (await (await fetch(origin)).text()).match(/name="token" value="([a-f0-9]+)"/)[1];
    const body = new URLSearchParams({ token, clientId: 'ID', clientSecret: 'SECRET', start: 'START', end: 'END' });
    body.append('clientSecret', 'SECOND_SECRET');
    assert.equal((await fetch(origin, { method: 'POST', body, headers: { Origin: origin } })).status, 403);
    assert.equal((await fetch(origin, { method: 'POST', body: 'x'.repeat(16385), headers: { Origin: origin, 'Content-Type': 'application/x-www-form-urlencoded' } })).status, 413);
    assert.equal((await fetch(origin, { method: 'POST', body: Buffer.from([0xff]), headers: { Origin: origin, 'Content-Type': 'application/x-www-form-urlencoded' } })).status, 502);
    assert.equal(calls, 0);
  } finally { await new Promise(resolve => { server.close(resolve); server.closeAllConnections(); }); }
});

test('provider errors never expose credentials in response or status', async () => {
  const server = createConnectionServer({ read: async () => { throw new Error('PRIVATE_SECRET and raw financial DATA'); } });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  try {
    const token = (await (await fetch(origin)).text()).match(/name="token" value="([a-f0-9]+)"/)[1];
    const body = new URLSearchParams({ token, clientId: 'ID', clientSecret: 'PRIVATE_SECRET', start: 'START', end: 'END' });
    const response = await fetch(origin, { method: 'POST', body, headers: { Origin: origin } });
    assert.equal(response.status, 502);
    for (const result of [await response.text(), await (await fetch(origin + '/status')).text()]) {
      assert.ok(!result.includes('PRIVATE_SECRET')); assert.ok(!result.includes('DATA'));
    }
  } finally { await new Promise(resolve => { server.close(resolve); server.closeAllConnections(); }); }
});

test('concurrent submissions cannot start multiple sandbox checks', async () => {
  let release, started; let calls = 0;
  const pending = new Promise(resolve => { release = resolve; });
  const didStart = new Promise(resolve => { started = resolve; });
  const server = createConnectionServer({ read: async () => {
    calls++; started(); await pending;
    return { mode: 'PAYPAL_SANDBOX_READ_ONLY', records: [], warnings: [] };
  } });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  let first;
  try {
    const token = (await (await fetch(origin)).text()).match(/name="token" value="([a-f0-9]+)"/)[1];
    const body = new URLSearchParams({ token, clientId: 'ID', clientSecret: 'SECRET', start: 'START', end: 'END' });
    first = fetch(origin, { method: 'POST', body, headers: { Origin: origin } });
    await didStart;
    assert.equal((await fetch(origin, { method: 'POST', body, headers: { Origin: origin } })).status, 409);
    release(); assert.equal((await first).status, 200); assert.equal(calls, 1);
  } finally { release(); if (first) await first.catch(() => {}); await new Promise(resolve => { server.close(resolve); server.closeAllConnections(); }); }
});
