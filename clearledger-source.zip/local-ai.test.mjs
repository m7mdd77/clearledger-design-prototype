import test from 'node:test';
import assert from 'node:assert/strict';
import { reviewWithLocalAI } from './local-ai.mjs';
import { reconcile } from './reconcile.mjs';

const report = () => reconcile([{ invoiceId: 'PRIVATE-ID', amount: '100.00', currency: 'USD' }], []);
const result = reviews => new Response(JSON.stringify({ done: true, message: { content: JSON.stringify({ reviews }) } }));
test('local model receives minimized evidence and cannot mutate ledger', async () => {
  const input = report(); const before = JSON.stringify(input);
  const output = await reviewWithLocalAI(input, { consent: true, model: 'installed-model', fetchImpl: async (url, opts) => {
    assert.equal(url, 'http://127.0.0.1:11434/api/chat');
    assert.equal(opts.redirect, 'error');
    assert.ok(!opts.body.includes('PRIVATE-ID')); assert.ok(!opts.body.includes('100.00'));
    return result([{ invoice: 'Invoice 001', priority: 1, action: 'check_missing_payment' }]);
  } });
  assert.equal(output.mode, 'LOCAL_MODEL_REVIEW'); assert.equal(JSON.stringify(input), before);
});
test('consent is required before network access', async () => {
  await assert.rejects(reviewWithLocalAI(report(), { model: 'model', fetchImpl: () => assert.fail('Network') }), /opt-in/);
});
test('invented actions and priorities are rejected', async () => {
  for (const row of [{ invoice: 'Invoice 001', priority: 1, action: 'refund' }, { invoice: 'Invoice 001', priority: 0, action: 'check_missing_payment' }]) {
    await assert.rejects(reviewWithLocalAI(report(), { consent: true, model: 'model', fetchImpl: async () => result([row]) }), /Invalid AI/);
  }
});
test('oversize and unavailable responses fail without credential details', async () => {
  for (const response of [new Response('x'.repeat(262145)), new Response('secret detail', { status: 500 })]) {
    await assert.rejects(reviewWithLocalAI(report(), { consent: true, model: 'model', fetchImpl: async () => response }), /^Error: Local AI unavailable; accounting unchanged$/);
  }
});
