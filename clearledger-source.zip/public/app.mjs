import { createReportSession } from '/report-session.mjs';
import { formatMinor, presentReport, statusNames, reasonNames } from '/presentation.mjs';

const $ = id => document.getElementById(id);
let report = null, synthetic = true, displayed = null;
const session = createReportSession();
function node(tag, text, className) { const element = document.createElement(tag); if (text != null) element.textContent = text; if (className) element.className = className; return element; }
function showMessage(text) { $('message').textContent = text; $('message').hidden = !text; }

function applyLoadedReport() {
  report = session.current; synthetic = report.mode === 'SYNTHETIC_DEMO';
  if ($('detail-dialog').open) $('detail-dialog').close();
  $('search').value = ''; $('status').value = 'all'; $('mask').checked = true;
  $('ai-results').hidden = true; $('ai-queue').replaceChildren();
  showMessage(''); render();
}

async function updateConnections() {
  try {
    const response = await fetch('/api/integrations'); if (!response.ok) throw new Error('Unavailable');
    const status = await response.json();
    $('sandbox-status').textContent = status.sandbox.status === 'verified' ? 'Reporting verified' : 'Not verified';
    $('sandbox-proof').textContent = status.sandbox.status === 'verified'
      ? `${status.sandbox.recordCount} reported record(s). Connection proof only; this ledger is not a sandbox report.` : '';
    $('ai-status').textContent = status.ai.status === 'model_available' ? 'Model available' : 'Unavailable';
  } catch { $('sandbox-status').textContent = 'Unavailable'; $('ai-status').textContent = 'Unavailable'; }
}

$('refresh-connections').addEventListener('click', updateConnections);
$('ai-review').addEventListener('click', () => { $('ai-consent').checked = false; $('ai-error').hidden = true; $('ai-dialog').showModal(); });
$('ai-form').addEventListener('submit', async event => {
  event.preventDefault(); if (!report || !$('ai-consent').checked) return;
  const submit = event.submitter; submit.disabled = true;
  const source = report;
  const aliases = new Map(report.invoices.map((row, index) => [row.invoiceId, `Invoice ${String(index + 1).padStart(3, '0')}`]));
  const evidence = { invoices: report.invoices.map(row => ({ invoiceId: aliases.get(row.invoiceId), status: row.status })),
    exceptions: report.exceptions.map(row => ({ invoiceId: aliases.get(row.invoiceId), reason: row.reason })) };
  try {
    const response = await fetch('/api/review', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ consent: true, report: evidence }) });
    if (!response.ok) throw new Error('Unavailable');
    const result = await response.json(); if (report !== source) return;
    const queue = document.createDocumentFragment();
    const labels = { check_reporting_window: 'Check reporting window', check_missing_payment: 'Investigate missing payment', review_overpayment: 'Review overpayment', review_exception: 'Review exception evidence' };
    for (const row of result.reviews) queue.append(node('li', `${row.invoice}: ${labels[row.action]} (priority ${row.priority})`));
    $('ai-queue').replaceChildren(queue); $('ai-results').hidden = false; $('ai-dialog').close();
    $('ai-status').textContent = 'Inference completed';
  } catch { $('ai-error').textContent = 'Local model review unavailable. The report was not changed.'; $('ai-error').hidden = false; }
  finally { submit.disabled = false; }
});

updateConnections();

function showDetails(row) {
  $('detail-title').textContent = row.invoiceId;
  const body = $('detail-body'); body.replaceChildren();
  const summary = node('div', null, 'detail-summary');
  for (const [label, value] of [['Status', statusNames[row.status]], ['Invoiced', formatMinor(row.dueMinor, row.currency)], ['Matched', formatMinor(row.paidMinor, row.currency)], ['Balance', formatMinor(row.balanceMinor, row.currency)]]) {
    const group = node('div'); group.append(node('p', label), node('strong', value)); summary.append(group);
  }
  body.append(summary, node('h3', 'Matched payment references'));
  const list = node('ul', null, 'detail-transactions');
  for (const id of row.transactionIds) list.append(node('li', id));
  if (!row.transactionIds.length) list.append(node('li', 'No eligible payment matched.'));
  body.append(list);
  const related = displayed.exceptions.filter(exception => exception.invoiceId === row.invoiceId);
  if (related.length) {
    body.append(node('h3', 'Related exceptions'));
    const exceptions = node('ul', null, 'detail-transactions');
    for (const exception of related) exceptions.append(node('li', `${exception.transactionId}: ${reasonNames[exception.reason] || 'Review required'}`));
    body.append(exceptions);
  }
  if (row.status === 'needs_review') body.append(node('p', 'A related exception prevents treating this invoice as settled. Review the source transactions before any follow-up.', 'form-note'));
  $('detail-dialog').showModal();
}

function render() {
  if (!report) return;
  displayed = presentReport(report, $('mask').checked);
  const rows = displayed.invoices;
  $('count-total').textContent = rows.length;
  $('count-paid').textContent = rows.filter(r => r.status === 'paid').length;
  $('count-outstanding').textContent = rows.filter(r => ['partial', 'unpaid'].includes(r.status)).length;
  $('count-review').textContent = rows.filter(r => ['needs_review', 'overpaid'].includes(r.status)).length;
  const term = $('search').value.trim().toLowerCase(), status = $('status').value;
  const filtered = rows.filter(row => (status === 'all' || row.status === status) && row.invoiceId.toLowerCase().includes(term));
  const fragment = document.createDocumentFragment();
  for (const row of filtered) {
    const tr = node('tr'); tr.append(node('td', row.invoiceId));
    const state = node('td'); state.append(node('span', statusNames[row.status], `pill ${row.status}`)); tr.append(state);
    for (const key of ['dueMinor', 'paidMinor', 'balanceMinor']) tr.append(node('td', formatMinor(row[key], row.currency), 'amount'));
    const action = node('td'); const button = node('button', null, 'row-review');
    const icon = node('i'); icon.setAttribute('data-lucide', 'chevron-right'); icon.setAttribute('aria-hidden', 'true'); button.append(icon);
    button.title = `Review ${row.invoiceId}`; button.setAttribute('aria-label', `Review ${row.invoiceId}`); button.addEventListener('click', () => showDetails(row)); action.append(button); tr.append(action); fragment.append(tr);
  }
  $('rows').replaceChildren(fragment); $('empty').hidden = filtered.length > 0;
  $('exception-count').textContent = displayed.exceptions.length;
  const exceptions = document.createDocumentFragment();
  for (const row of displayed.exceptions) { const item = node('div', null, 'exception'); item.append(node('strong', row.transactionId), node('p', reasonNames[row.reason] || 'Unclassified event requires review')); exceptions.append(item); }
  if (!displayed.exceptions.length) exceptions.append(node('p', 'No exceptions in this report.', 'ledger-note'));
  $('exceptions').replaceChildren(exceptions);
  const warnings = document.createDocumentFragment();
  for (const warning of displayed.warnings) warnings.append(node('li', typeof warning === 'string' ? warning : `${warning.transactionId}: ${reasonNames[warning.reason] || 'Review required'}`));
  $('warnings').replaceChildren(warnings);
  $('source-label').textContent = synthetic ? 'Synthetic sample · PayPal-shaped records' : 'Local import · Source and completeness unverified';
  document.querySelector('.environment').replaceChildren(node('span', null, 'dot'), document.createTextNode(synthetic ? 'Synthetic demo' : 'Unverified import'));
  window.lucide?.createIcons();
}

async function loadDemo() {
  try {
    const committed = await session.load(async () => {
      const [invoices, records] = await Promise.all(['/fixtures/invoices.json', '/fixtures/transactions.json'].map(async url => { const response = await fetch(url); if (!response.ok) throw new Error('unavailable'); return response.json(); }));
      return { invoices, records };
    }, 'SYNTHETIC_DEMO');
    if (committed) applyLoadedReport();
  } catch { showMessage('The synthetic sample could not be loaded. Retry or import local JSON files.'); }
}

async function readFile(input) {
  const file = input.files[0]; if (!file || file.size > 4_000_000) throw new Error('Select a JSON file under 4 MB.');
  return JSON.parse(await file.text());
}
$('import').addEventListener('click', () => { $('import-error').hidden = true; $('import-dialog').showModal(); });
$('import-form').addEventListener('submit', async event => {
  event.preventDefault(); const submit = event.submitter; submit.disabled = true;
  try {
    const committed = await session.load(async () => ({ invoices: await readFile($('invoice-file')), records: await readFile($('transaction-file')) }), 'LOCAL_IMPORT_UNVERIFIED_SOURCE');
    if (committed) { $('import-dialog').close(); $('import-form').reset(); applyLoadedReport(); }
  } catch {
    $('import-error').textContent = 'Import stopped. Check both JSON arrays, unique IDs, supported currency precision, and linked transaction references. The previous report was not changed.'; $('import-error').hidden = false;
  } finally { submit.disabled = false; }
});
$('export').addEventListener('click', () => {
  if (!report) return;
  const exportReport = presentReport(report, $('mask').checked);
  const url = URL.createObjectURL(new Blob([JSON.stringify(exportReport, null, 2)], { type: 'application/json' }));
  const link = node('a'); link.href = url; link.download = `clearledger-${synthetic ? 'synthetic' : 'import'}-${$('mask').checked ? 'masked' : 'full'}.json`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
});
for (const id of ['search', 'status', 'mask']) $(id).addEventListener(id === 'search' ? 'input' : 'change', () => { if ($('detail-dialog').open) $('detail-dialog').close(); render(); });
$('demo').addEventListener('click', loadDemo);
document.querySelectorAll('[data-close]').forEach(button => button.addEventListener('click', () => $(button.dataset.close).close()));
await loadDemo();
