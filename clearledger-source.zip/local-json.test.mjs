import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { readLocalJson } from './local-json.mjs';

async function fixture(run) {
  const directory = await mkdtemp(join(tmpdir(), 'clearledger-json-test-'));
  try { await run(directory); } finally { await rm(directory, { recursive: true, force: true }); }
}
test('bounded local read accepts valid JSON at exact byte limit', () => fixture(async directory => {
  const path = join(directory, 'input.json'); await writeFile(path, '[1]');
  assert.deepEqual(await readLocalJson(path, { maxBytes: 3 }), [1]);
}));
test('byte limits count UTF-8 bytes, not decoded character length', () => fixture(async directory => {
  const path = join(directory, 'input.json'); await writeFile(path, '"\u00e9"');
  await assert.rejects(readLocalJson(path, { maxBytes: 3 }), /oversized/);
  assert.equal(await readLocalJson(path, { maxBytes: 4 }), '\u00e9');
}));
test('malformed JSON, invalid UTF-8 and directories fail with sanitized errors', () => fixture(async directory => {
  const path = join(directory, 'PRIVATE-input.json');
  for (const data of ['not JSON', Buffer.from([0x22, 0xff, 0x22]), '']) {
    await writeFile(path, data);
    await assert.rejects(readLocalJson(path), error => !error.message.includes('PRIVATE') && /Invalid/.test(error.message));
  }
  await assert.rejects(readLocalJson(directory), /Invalid/);
  await assert.rejects(readLocalJson(join(directory, 'PRIVATE-missing.json')), /Invalid/);
}));
test('invalid configured limits fail before reading any file', async () => {
  for (const maxBytes of [0, -1, Infinity, NaN, 4_000_001, 1.1, '4']) {
    await assert.rejects(readLocalJson('PRIVATE', { maxBytes }), /Invalid input limit/);
  }
});
