import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createLocalServer } from './server.mjs';
import { formatMinor, presentReport } from './presentation.mjs';
import { reconcile } from './reconcile.mjs';

test('display formatting keeps precision without floating point', () => {
  assert.equal(formatMinor('12501', 'BHD'), '12.501 BHD');
  assert.equal(formatMinor('-1', 'USD'), '-0.01 USD');
  assert.equal(formatMinor('9999999999999999999999', 'USD'), '99,999,999,999,999,999,999.99 USD');
  assert.throws(() => formatMinor('1.2', 'USD'));
});
test('masked reports do not disclose invoice or transaction identifiers', () => {
  const report = { ...reconcile([{ invoiceId: 'PRIVATE_INVOICE', amount: '10.00', currency: 'USD' }], [
    { transactionId: 'PRIVATE_TX', invoiceId: 'PRIVATE_INVOICE', amount: '5.00', currency: 'USD', status: 'completed', kind: 'payment' },
  ]), mode: 'LOCAL_IMPORT_UNVERIFIED_SOURCE', warnings: [{ transactionId: 'PRIVATE_TX', reason: 'missing_invoice_reference' }] };
  const before = JSON.stringify(report), masked = JSON.stringify(presentReport(report));
  assert.ok(!masked.includes('PRIVATE_')); assert.equal(JSON.stringify(report), before);
  assert.ok(JSON.stringify(presentReport(report, false)).includes('PRIVATE_INVOICE'));
});
test('transaction aliases remain consistent across invoice and exception views', () => {
  const report = { invoices: [{ invoiceId: 'I', currency: 'USD', dueMinor: '10', paidMinor: '10', balanceMinor: '0', status: 'needs_review', transactionIds: ['T'] }],
    exceptions: [{ transactionId: 'R', reason: 'non_payment_or_refund' }], warnings: [{ transactionId: 'R', reason: 'reference_outside_window_or_unavailable' }], notice: 'Read-only' };
  const view = presentReport(report);
  assert.equal(view.exceptions[0].transactionId, view.warnings[0].transactionId);
  assert.notEqual(view.invoices[0].transactionIds[0], view.exceptions[0].transactionId);
});
test('loopback server serves UI and refuses mutations and private files', async () => {
  const server = createLocalServer();
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  try {
    const home = await fetch(base); assert.equal(home.status, 200);
    assert.match(home.headers.get('content-security-policy'), /connect-src 'self'/);
    assert.match(await home.text(), /Synthetic demo/);
    for (const path of ['/app.mjs', '/icons.js', '/reconcile.mjs', '/paypal-sandbox.mjs', '/presentation.mjs', '/report-session.mjs', '/fixtures/invoices.json', '/fixtures/transactions.json'])
      assert.equal((await fetch(base + path)).status, 200);
    for (const path of ['/README.md', '/.env', '/package.json', '/sandbox.test.mjs', '/api/payments', '/api/sandbox'])
      assert.equal((await fetch(base + path)).status, 404);
    assert.equal((await fetch(base, { method: 'POST', body: 'private data' })).status, 405);
    const invalidHostStatus = await new Promise((resolve, reject) => {
      http.get(base, { headers: { Host: 'evil.example' } }, response => { response.resume(); resolve(response.statusCode); }).on('error', reject);
    });
    assert.equal(invalidHostStatus, 403);
    const health = await (await fetch(base + '/health')).json(); assert.equal(health.liveIntegrations, false);
  } finally { await new Promise(resolve => { server.close(resolve); server.closeAllConnections(); }); }
});
