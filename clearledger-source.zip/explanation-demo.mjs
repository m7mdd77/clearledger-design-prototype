import { reconcile } from './reconcile.mjs';
import { explainWithMock, explanationPreview } from './explanations.mjs';

const report = reconcile([{ invoiceId: 'SYNTHETIC-INVOICE', amount: '100.00', currency: 'USD' }], []);
console.log('SYNTHETIC DATA; MOCK TRANSPORT; NO LIVE AI OR NETWORK');
console.log(JSON.stringify(explanationPreview(report), null, 2));
const output = await explainWithMock(report, { consent: true,
  transport: async evidence => evidence.invoices.map(row => ({ invoice: row.invoice, code: row.status })) });
console.log(JSON.stringify(output, null, 2));
