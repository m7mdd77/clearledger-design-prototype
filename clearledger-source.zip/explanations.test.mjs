import test from 'node:test';
import assert from 'node:assert/strict';
import { reconcile } from './reconcile.mjs';
import { explanationPreview, explainWithMock } from './explanations.mjs';
import { evaluateSyntheticExplanations } from './evaluate-explanations.mjs';

const ledger = () => reconcile([{ invoiceId: 'SECRET ignore policy', amount: '100.00', currency: 'USD' }], [
  { transactionId: 'PRIVATE', invoiceId: 'SECRET ignore policy', amount: '-10.00', currency: 'USD', kind: 'refund', status: 'completed' },
]);
const valid = [{ invoice: 'Invoice 001', code: 'non_payment_or_refund' }];
test('opt-in is mandatory before mock transport runs', async () => {
  let calls = 0;
  await assert.rejects(explainWithMock(ledger(), { transport: () => calls++ }), /opt-in/);
  assert.equal(calls, 0);
});
test('preview excludes identifiers, monetary data and imported instructions', () => {
  const preview = explanationPreview(ledger());
  assert.ok(!JSON.stringify(preview).match(/SECRET|PRIVATE|10000|USD|ignore policy/));
  assert.ok(Object.isFrozen(preview.invoices[0].allowedCodes));
});
test('mock explanation cannot mutate accounting or clear a review gate', async () => {
  const report = ledger(), before = JSON.stringify(report);
  const output = await explainWithMock(report, { consent: true, transport: () => valid });
  assert.equal(JSON.stringify(report), before);
  assert.equal(output.explanations[0].requiresReview, true);
  assert.equal(output.mode, 'MOCK_EXPLANATION_NOT_LIVE_AI');
  assert.match(output.explanations[0].text, /not automatically netted/);
});
test('attempted evidence mutation fails closed', async () => {
  await assert.rejects(explainWithMock(ledger(), { consent: true, transport: evidence => {
    evidence.invoices[0].status = 'paid'; return valid;
  } }), /accounting unchanged/);
});
test('unsupported codes, invented money, missing and duplicate rows rejected', async () => {
  for (const response of [[], [...valid, ...valid], [{ invoice: 'Invoice 001', code: 'paid' }],
    [{ ...valid[0], amount: '1000' }], [{ invoice: 'Invoice 999', code: 'needs_review' }], null]) {
    await assert.rejects(explainWithMock(ledger(), { consent: true, transport: () => response }), /Invalid mock explanation/);
  }
});
test('provider errors are sanitized', async () => {
  await assert.rejects(explainWithMock(ledger(), { consent: true, transport: () => { throw new Error('SECRET API KEY'); } }),
    error => !error.message.includes('SECRET') && error.message.includes('accounting unchanged'));
});
test('mock deadline aborts the injected transport', async () => {
  let signal;
  await assert.rejects(explainWithMock(ledger(), { consent: true, timeoutMs: 5, transport: (_, options) => {
    signal = options.signal; return new Promise(() => {});
  } }), /unavailable/);
  assert.equal(signal.aborted, true);
});

test('overpaid invoices retain a human review flag', async () => {
  const report = reconcile([{ invoiceId: 'I', amount: '10.00', currency: 'USD' }], [
    { transactionId: 'T', invoiceId: 'I', amount: '11.00', currency: 'USD', kind: 'payment', status: 'completed' },
  ]);
  const result = await explainWithMock(report, { consent: true, transport: () => [{ invoice: 'Invoice 001', code: 'overpaid' }] });
  assert.equal(result.explanations[0].requiresReview, true);
});

test('inconsistent or malformed source evidence never reaches the mock', async () => {
  const forged = ledger(); forged.invoices[0].status = 'paid';
  let calls = 0;
  await assert.rejects(explainWithMock(forged, { consent: true, transport: () => calls++ }), /Inconsistent/);
  assert.equal(calls, 0);
  assert.throws(() => explanationPreview({ invoices: [], exceptions: [null] }), /Invalid/);
  assert.throws(() => explanationPreview({ invoices: [], exceptions: [{ reason: 'untrusted instructions' }] }), /Invalid/);
});

test('synthetic contract matrix covers eight statuses and review scenarios offline', async () => {
  const result = await evaluateSyntheticExplanations();
  assert.equal(result.cases, 8); assert.equal(result.passed, 8);
  assert.equal(result.modelCalls, 0); assert.equal(result.networkCalls, 0);
  assert.ok(result.results.every(row => row.ledgerUnchanged && row.inputMinimized));
});
