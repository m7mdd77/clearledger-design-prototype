import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { integrationStatus } from './integration-status.mjs';
import { reviewWithLocalAI } from './local-ai.mjs';

const routes = new Map([
  ['/', ['public/index.html', 'text/html']], ['/app.mjs', ['public/app.mjs', 'text/javascript']],
  ['/style.css', ['public/style.css', 'text/css']], ['/reconcile.mjs', ['reconcile.mjs', 'text/javascript']],
  ['/paypal-sandbox.mjs', ['paypal-sandbox.mjs', 'text/javascript']], ['/presentation.mjs', ['presentation.mjs', 'text/javascript']],
  ['/report-session.mjs', ['report-session.mjs', 'text/javascript']],
  ['/fixtures/invoices.json', ['fixtures/invoices.json', 'application/json']], ['/fixtures/transactions.json', ['fixtures/transactions.json', 'application/json']],
  ['/favicon.svg', ['public/favicon.svg', 'image/svg+xml']],
  ['/icons.js', ['node_modules/lucide/dist/umd/lucide.js', 'text/javascript']],
]);

export function createLocalServer({ statusReader = integrationStatus, aiReviewer = reviewWithLocalAI } = {}) {
  return http.createServer(async (request, response) => {
    response.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");
    response.setHeader('X-Content-Type-Options', 'nosniff');
    response.setHeader('Referrer-Policy', 'no-referrer');
    response.setHeader('Cache-Control', 'no-store');
    const port = request.socket.localPort;
    if (request.headers.host !== `127.0.0.1:${port}`) { response.writeHead(403); response.end('Host not allowed'); return; }
    const path = new URL(request.url, `http://127.0.0.1:${port}`).pathname;
    if (path === '/api/review' && request.method === 'POST') {
      if (request.headers.origin !== `http://127.0.0.1:${port}` || !/^application\/json(?:;\s*charset=utf-8)?$/i.test(request.headers['content-type'] || '')) {
        response.writeHead(403); response.end('Same-origin JSON required'); return;
      }
      try {
        const buffer = Buffer.alloc(65536); let size = 0;
        for await (const chunk of request) {
          if (chunk.length > buffer.length - size) { response.writeHead(413); response.end('Review too large'); return; }
          chunk.copy(buffer, size); size += chunk.length;
        }
        const input = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(buffer.subarray(0, size)));
        if (input.consent !== true) { response.writeHead(400); response.end('Explicit AI consent required'); return; }
        const review = await aiReviewer(input.report, { consent: true, model: process.env.LOCAL_AI_MODEL || 'qwen2.5:0.5b' });
        response.writeHead(200, { 'Content-Type': 'application/json' }); response.end(JSON.stringify(review));
      } catch { response.writeHead(503); response.end('AI review unavailable; accounting unchanged'); }
      return;
    }
    if (request.method !== 'GET') { response.writeHead(405, { Allow: 'GET' }); response.end('Read-only server'); return; }
    if (path === '/api/integrations') {
      try {
        const status = await statusReader({ model: process.env.LOCAL_AI_MODEL || 'qwen2.5:0.5b' });
        response.writeHead(200, { 'Content-Type': 'application/json' }); response.end(JSON.stringify(status));
      } catch { response.writeHead(503); response.end('Connection status unavailable'); }
      return;
    }
    if (path === '/health') { response.writeHead(200, { 'Content-Type': 'application/json' }); response.end(JSON.stringify({ status: 'ok', mode: 'local-import-and-synthetic-demo', liveIntegrations: false })); return; }
    const route = routes.get(path);
    if (!route) { response.writeHead(404); response.end('Not found'); return; }
    try {
      const content = await readFile(new URL(route[0], import.meta.url));
      response.writeHead(200, { 'Content-Type': `${route[1]}; charset=utf-8` }); response.end(content);
    } catch { response.writeHead(500); response.end('Local resource unavailable'); }
  });
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const port = Number(process.env.RECONCILE_PORT || 3221);
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Invalid local port');
  const server = createLocalServer();
  server.on('error', error => { console.error(`Local server stopped: ${error.code || 'server_error'}`); process.exitCode = 1; });
  server.listen(port, '127.0.0.1', () => console.log(`Reconciliation workspace: http://127.0.0.1:${port}`));
}
