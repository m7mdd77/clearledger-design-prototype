import { open } from 'node:fs/promises';
import { TextDecoder } from 'node:util';

export async function readLocalJson(path, { maxBytes = 4_000_000 } = {}) {
  if (!Number.isInteger(maxBytes) || maxBytes < 1 || maxBytes > 4_000_000) throw new Error('Invalid input limit');
  let file;
  try {
    file = await open(path, 'r');
    const stats = await file.stat();
    if (!stats.isFile() || stats.size > maxBytes) throw new Error('Input exceeds limit');
    // Read one extra byte to catch growth after the size check, without unbounded allocation.
    const buffer = Buffer.alloc(maxBytes + 1);
    let length = 0;
    while (length < buffer.length) {
      const { bytesRead } = await file.read(buffer, length, buffer.length - length, null);
      if (!bytesRead) break;
      length += bytesRead;
    }
    if (length > maxBytes) throw new Error('Input exceeds limit');
    return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(buffer.subarray(0, length)));
  } catch {
    throw new Error('Invalid, unreadable or oversized local JSON');
  } finally {
    if (file) await file.close();
  }
}
