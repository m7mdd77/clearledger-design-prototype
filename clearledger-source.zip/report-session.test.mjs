import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createReportSession } from './report-session.mjs';
import { presentReport } from './presentation.mjs';

const fixture = async () => ({ invoices: JSON.parse(await readFile(new URL('./fixtures/invoices.json', import.meta.url))),
  records: JSON.parse(await readFile(new URL('./fixtures/transactions.json', import.meta.url))) });
const pending = () => { let resolve, reject; const promise = new Promise((yes, no) => { resolve = yes; reject = no; }); return { promise, resolve, reject }; };

test('valid import commits only a fully reconciled report with refund gate', async () => {
  const session = createReportSession();
  assert.equal(await session.load(fixture, 'LOCAL_IMPORT_UNVERIFIED_SOURCE'), true);
  assert.equal(session.current.mode, 'LOCAL_IMPORT_UNVERIFIED_SOURCE');
  assert.equal(session.current.invoices.find(row => row.status === 'needs_review').status, 'needs_review');
});
test('invalid import and read errors preserve the previous report exactly', async () => {
  const session = createReportSession(); await session.load(fixture, 'SYNTHETIC_DEMO');
  const original = session.current, before = JSON.stringify(original);
  const data = await fixture(); data.invoices.push(data.invoices[0]);
  for (const loader of [() => data, () => { throw new Error('PRIVATE PATH'); }, () => ({ invoices: null, records: [] })]) {
    await assert.rejects(session.load(loader, 'LOCAL_IMPORT_UNVERIFIED_SOURCE'), /previous report preserved/);
    assert.equal(session.current, original); assert.equal(JSON.stringify(session.current), before);
  }
});
test('slow demo completion cannot overwrite a newer import', async () => {
  const session = createReportSession(), slow = pending();
  const demo = session.load(() => slow.promise, 'SYNTHETIC_DEMO');
  await session.load(fixture, 'LOCAL_IMPORT_UNVERIFIED_SOURCE');
  const imported = session.current;
  slow.resolve(await fixture()); assert.equal(await demo, false);
  assert.equal(session.current, imported);
});
test('stale errors do not replace a newer successful report or show a current failure', async () => {
  const session = createReportSession(), slow = pending();
  const old = session.load(() => slow.promise, 'LOCAL_IMPORT_UNVERIFIED_SOURCE');
  await session.load(fixture, 'SYNTHETIC_DEMO');
  slow.reject(new Error('PRIVATE PATH')); assert.equal(await old, false);
  assert.equal(session.current.mode, 'SYNTHETIC_DEMO');
});
test('new invalid request prevents an older pending request from replacing previous state', async () => {
  const session = createReportSession(); await session.load(fixture, 'SYNTHETIC_DEMO');
  const original = session.current, slow = pending();
  const old = session.load(() => slow.promise, 'SYNTHETIC_DEMO');
  await assert.rejects(session.load(() => ({ invoices: [], records: null }), 'LOCAL_IMPORT_UNVERIFIED_SOURCE'));
  slow.resolve(await fixture()); assert.equal(await old, false); assert.equal(session.current, original);
});
test('masked export round trip preserves money and related refund aliases without raw IDs', async () => {
  const session = createReportSession(); await session.load(fixture, 'LOCAL_IMPORT_UNVERIFIED_SOURCE');
  const json = JSON.stringify(presentReport(session.current, true));
  assert.ok(!json.includes('DEMO-'));
  const exported = JSON.parse(json);
  assert.deepEqual(exported.invoices.map(row => [row.dueMinor, row.paidMinor, row.balanceMinor, row.status]),
    session.current.invoices.map(row => [row.dueMinor, row.paidMinor, row.balanceMinor, row.status]));
  const refund = exported.exceptions.find(row => row.reason === 'non_payment_or_refund');
  assert.ok(exported.invoices.some(row => row.invoiceId === refund.invoiceId && row.status === 'needs_review'));
});
